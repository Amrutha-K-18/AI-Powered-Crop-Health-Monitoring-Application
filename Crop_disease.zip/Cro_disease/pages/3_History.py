import streamlit as st
import json
import os

st.title("📜 Prediction History")

file_path = "history.json"

if not os.path.exists(file_path):
    st.warning("No history file found")
else:
    with open(file_path) as f:
        data = json.load(f)

    if len(data) == 0:
        st.warning("No history yet")
    else:
        for item in reversed(data):
            st.markdown("---")

            st.subheader("🌿 Disease Details")

            st.write(f"🌿 Disease: {item.get('disease', '-')}")
            st.write(f"📊 Confidence: {item.get('confidence', 0)*100:.2f}%")
            st.write(f"🌦 Weather: {item.get('weather', '-')}")
            st.write(f"🌡 Temperature: {item.get('temperature', '-')}")
            
            st.write(f"🌾 Recommended Crop: {item.get('crop', '-')}")
            
            st.write(f"💊 Treatment: {item.get('treatment', '-')}")
            st.write(f"📘 Disease Info: {item.get('info', '-')}")
            
            st.write(f"🌱 Soil Type: {item.get('soil', '-')}")
            st.write(f"🌿 Soil Crop: {item.get('soil_crop', '-')}")
            
            st.write(f"🧪 Fertilizer: {item.get('fertilizer', '-')}")
            st.write(f"⚠️ Severity: {item.get('severity', '-')}")