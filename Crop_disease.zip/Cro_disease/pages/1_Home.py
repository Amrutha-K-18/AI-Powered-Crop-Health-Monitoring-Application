import streamlit as st

st.title("🌿 Welcome to Smart Agri AI")

st.markdown("""
### 🚀 Features
✔ Disease Detection  
✔ Real-time Weather  
✔ Smart Crop Recommendation  
✔ Treatment Suggestions  
✔ Voice Output  
✔ Multilingual Support  

👉 Go to Predict Page
""")

st.image("https://images.unsplash.com/photo-1501004318641-b39e6451bec6", use_column_width=True)