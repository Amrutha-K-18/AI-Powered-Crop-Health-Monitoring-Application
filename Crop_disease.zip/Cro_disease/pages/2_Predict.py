import streamlit as st

from utils import (
    predict,
    get_weather,
    recommend_crop,
    save_history,
    get_treatment,
    get_disease_info,
    translate_text,
    speak_text,
    translations,
    recommend_by_soil,
    estimate_severity,
    recommend_fertilizer
)

# =========================
# 🌍 LANGUAGE SELECT (NATIVE)
# =========================
language_map = {
    "English": "English",
    "Kannada": "ಕನ್ನಡ",
    "Hindi": "हिंदी",
    "Tamil": "தமிழ்",
    "Telugu": "తెలుగు"
}

lang_display = st.selectbox("🌍 Language", list(language_map.values()))
lang = {v: k for k, v in language_map.items()}[lang_display]

# UI text
t = translations[lang]
soil_dict = {
    "Loamy": {
        "English": "Loamy",
        "Kannada": "ಲೋಮಿ",
        "Hindi": "दोमट",
        "Tamil": "சேறு மண்",
        "Telugu": "లోమి మట్టి"
    },
    "Sandy": {
        "English": "Sandy",
        "Kannada": "ಮರಳು ಮಣ್ಣು",
        "Hindi": "रेतीली मिट्टी",
        "Tamil": "மணல் மண்",
        "Telugu": "మణి మట్టి"
    },
    "Clayey": {
        "English": "Clayey",
        "Kannada": "ಮಣ್ಣಿನ ಮಣ್ಣು",
        "Hindi": "चिकनी मिट्टी",
        "Tamil": "களிமண்",
        "Telugu": "బురద మట్టి"
    },
    "Black": {
        "English": "Black",
        "Kannada": "ಕಪ್ಪು ಮಣ್ಣು",
        "Hindi": "काली मिट्टी",
        "Tamil": "கருப்பு மண்",
        "Telugu": "నల్ల మట్టి"
    }
}
severity_map = {
    "High ⚠️": {
        "Kannada": "ಹೆಚ್ಚು ⚠️",
        "Hindi": "उच्च ⚠️",
        "Tamil": "அதிகம் ⚠️",
        "Telugu": "అధికం ⚠️"
    },
    "Medium ⚠️": {
        "Kannada": "ಮಧ್ಯಮ ⚠️",
        "Hindi": "मध्यम ⚠️",
        "Tamil": "மிதமான ⚠️",
        "Telugu": "మధ్యస్థ ⚠️"
    },
    "Low ✅": {
        "Kannada": "ಕಡಿಮೆ ✅",
        "Hindi": "कम ✅",
        "Tamil": "குறைவு ✅",
        "Telugu": "తక్కువ ✅"
    }
}
# =========================
# 🎨 PAGE TITLE
# =========================
st.markdown(f"## 🔍 {translate_text('Crop Disease Detection', lang)}")

# =========================
# 📍 INPUTS
# =========================
city = st.text_input(t["city"], "Bangalore")
soil_options = [soil_dict[s][lang] for s in soil_dict]
soil_display = st.selectbox(t["soil_crop"], soil_options)

# Convert back to original value
soil = list(soil_dict.keys())[soil_options.index(soil_display)]
file = st.file_uploader(t["upload"], type=["jpg", "png"])

# store results (to fix speak bug)
if "result" not in st.session_state:
    st.session_state.result = None

# =========================
# 🔍 PREDICTION
# =========================
if file:
    st.image(file, width=300)

    if st.button(t["predict"]):
        label, conf = predict(file)

        weather, temp = get_weather(city)
        crop = recommend_crop(weather, temp)
        treatment = get_treatment(label)
        info = get_disease_info(label)
        soil_crop = recommend_by_soil(soil)
        severity_raw = estimate_severity(conf)

# convert to local language
        severity = severity_map.get(severity_raw, {}).get(lang, severity_raw)
        fertilizer = recommend_fertilizer(label)

        # translate everything
        label_t = translate_text(label, lang)
        weather_t = translate_text(weather, lang)
        crop_t = translate_text(crop, lang)
        treatment_t = translate_text(treatment, lang)
        info_t = translate_text(info, lang)
        soil_crop = translate_text(soil_crop, lang)
        fertilizer = translate_text(fertilizer, lang)
        severity = translate_text(severity, lang)
        soil_options = {
            "Loamy": translate_text("Loamy", lang),
            "Sandy": translate_text("Sandy", lang),
            "Clayey": translate_text("Clayey", lang),
            "Black": translate_text("Black", lang)
        }
        #save history
        save_history({
            "disease": label,
            "confidence": conf,
            "weather": weather,
            "treatment": treatment,
            "info": info, 
            "soil_crop": soil_crop,
            "severity": severity,
            "fertilizer": fertilizer
        })


        # display
        st.success(f"🌿 {label_t}")
        st.info(f"📊 {t['confidence']}: {conf*100:.2f}%")
        st.warning(f"🌦 {t['weather']}: {weather_t}, {temp}°C")
        st.success(f"🌾 {t['crop']}: {crop_t}")
        st.error(f"💊 {t['treatment']}: {treatment_t}")
        st.info(f"📘 {t['info']}: {info_t}")
        st.info(f"🌱 {t['soil_crop']}: {soil_crop}")
        st.warning(f"⚠️ {t['severity']}: {severity}")
        st.success(f"🧪 {t['fertilizer']}: {fertilizer}")


        # store result for speech
        st.session_state.result = {
            "label": label_t,
            "info": info_t,
            "treatment": treatment_t,
            "weather": f"{weather_t}, {temp}°C",
            "soil_crop": soil_crop,
            "severity": severity,
            "fertilizer": fertilizer,

        }

# =========================
# 🔊 SPEAK BUTTON (FIXED)
# =========================
if st.session_state.result:
    if st.button(f"🔊 {t['speak']}"):
        try:
            text = f"predicted disease is {st.session_state.result['label']}. disease info is {st.session_state.result['info']}. Treatment is {st.session_state.result['treatment']}. Weather is {st.session_state.result['weather']}. Recommended crop for soil is {st.session_state.result['soil_crop']}. Severity level is {st.session_state.result['severity']}. Recommended fertilizer is {st.session_state.result['fertilizer']}."
            speak_text(text, lang)
            st.success("🔊 Speaking...")
        except Exception as e:
            st.error(f"Speech error: {e}")