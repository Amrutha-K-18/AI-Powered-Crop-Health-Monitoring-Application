🌿 AI-Powered Crop Health Monitoring Application
An intelligent agriculture-focused web application that uses Deep Learning and Computer Vision to detect crop diseases from leaf images and provide smart farming recommendations. The system is built using TensorFlow, CNN, MobileNetV2, Python, and Streamlit to deliver accurate real-time disease prediction with an interactive user interface.

🚀 Features
🌱 Crop disease detection using CNN & MobileNetV2
📊 Confidence score and severity analysis
🌦 Real-time weather-based crop recommendations
🧪 Fertilizer and treatment suggestions
🌍 Multilingual support (English, Kannada, Hindi, Tamil, Telugu)
🔊 Voice output for prediction results
📜 Prediction history tracking
🎨 User-friendly and responsive Streamlit interface

🛠 Tech Stack
Python, Streamlit, TensorFlow, CNN, MobileNetV2, NumPy, OpenCV, gTTS

🎯 Objective
To assist farmers with early disease detection and intelligent crop management using AI-driven solutions for sustainable agriculture.