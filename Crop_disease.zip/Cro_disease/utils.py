import tensorflow as tf
import numpy as np
from PIL import Image
import json
import random
import os
import requests

from config import API_KEY  # ✅ using your config file

# 🌍 Translation & Voice
from googletrans import Translator
from gtts import gTTS

translator = Translator()

# =========================
# 📦 LOAD MODEL + LABELS
# =========================
model = tf.keras.models.load_model("plant_disease_model.h5", compile=False)

with open("labels.json") as f:
    labels = json.load(f)

labels_inv = {v: k for k, v in labels.items()}

# =========================
# 🌿 PREDICTION
# =========================
def predict(image):
    img = Image.open(image).convert("RGB")
    img = img.resize((224, 224))
    img = np.array(img) / 255.0
    img = np.expand_dims(img, axis=0)

    pred = model.predict(img)
    class_id = np.argmax(pred)
    confidence = float(np.max(pred))

    return labels_inv[class_id], confidence


# =========================
# 🌦 WEATHER (REAL API)
# =========================
def get_weather(city):
    try:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
        res = requests.get(url).json()

        weather = res["weather"][0]["main"]
        temp = res["main"]["temp"]

        return weather, temp

    except:
        # fallback
        data = [
            ("Sunny", 32),
            ("Rainy", 25),
            ("Cloudy", 28)
        ]
        return random.choice(data)


# =========================
# 🌾 CROP RECOMMENDATION
# =========================
def recommend_crop(weather, temp):
    weather = weather.lower()

    if "rain" in weather:
        return "Rice, Sugarcane, Paddy, Banana"
    elif "clear" in weather or "sun" in weather:
        return "Cotton, Groundnut, Maize, Millets"
    elif "cloud" in weather:
        return "Potato, Tomato, Pulses, Vegetables"
    else:
        return "Vegetables, Pulses"


# =========================
# 💊 TREATMENT (ALL CLASSES)
# =========================
treatment_db = {
    "Pepper__bell___Bacterial_spot": "Remove infected leaves. Use copper-based bactericides.",
    "Pepper__bell___healthy": "No treatment needed. Maintain proper care.",
    
    "Potato___Early_blight": "Apply fungicides like chlorothalonil.",
    "Potato___Late_blight": "Use resistant varieties and fungicides.",
    "Potato___healthy": "Healthy crop. Maintain irrigation and nutrients.",
    
    "Tomato_Bacterial_spot": "Use copper sprays and remove infected parts.",
    "Tomato_Early_blight": "Use fungicides and remove affected leaves.",
    "Tomato_Late_blight": "Avoid wet leaves and apply fungicides.",
    "Tomato_Leaf_Mold": "Improve air circulation and reduce humidity.",
    "Tomato_Septoria_leaf_spot": "Remove infected leaves and apply fungicide.",
    "Tomato_Spider_mites_Two_spotted_spider_mite": "Use insecticidal soap or neem oil.",
    "Tomato__Target_Spot": "Apply fungicides and crop rotation.",
    "Tomato__Tomato_mosaic_virus": "Remove infected plants. No cure.",
    "Tomato__Tomato_YellowLeaf__Curl_Virus": "Control whiteflies and remove infected plants.",
    "Tomato__healthy": "Healthy plant. Maintain care."
}


def get_treatment(label):
    return treatment_db.get(label, "Maintain proper irrigation and plant care.")


# =========================
# 📘 DISEASE INFO (ALL)
# =========================
info_db = {
    "Pepper__bell___Bacterial_spot": "Causes dark lesions on leaves and fruits.",
    "Pepper__bell___healthy": "Healthy plant with no disease.",
    
    "Potato___Early_blight": "Causes brown spots and leaf drop.",
    "Potato___Late_blight": "Serious disease causing crop failure.",
    "Potato___healthy": "Healthy crop.", 
    
    "Tomato_Bacterial_spot": "Small dark spots on leaves and fruits.",
    "Tomato_Early_blight": "Shows concentric ring spots.",
    "Tomato_Late_blight": "Spreads quickly in wet conditions.",
    "Tomato_Leaf_Mold": "Yellow spots on leaves with mold.",
    "Tomato_Septoria_leaf_spot": "Small circular spots with dark borders.",
    "Tomato_Spider_mites_Two_spotted_spider_mite": "Tiny insects damaging leaves.",
    "Tomato__Target_Spot": "Brown lesions with rings.",
    "Tomato__Tomato_mosaic_virus": "Causes mottled leaves and reduced yield.",
    "Tomato__Tomato_YellowLeaf__Curl_Virus": "Leaves curl and turn yellow.",
    "Tomato_healthy": "Healthy plant."
}


def get_disease_info(label):
    return info_db.get(label, "No detailed info available.")


# =========================
# 🌍 TRANSLATION
# =========================
def translate_text(text, lang):
    lang_codes = {
        "English": "en",
        "Kannada": "kn",
        "Hindi": "hi",
        "Tamil": "ta",
        "Telugu": "te"
    }

    try:
        return translator.translate(text, dest=lang_codes[lang]).text
    except:
        return text


# =========================
# 🔊 SPEECH
# =========================
def speak_text(text, lang):
    lang_codes = {
        "English": "en",
        "Kannada": "kn",
        "Hindi": "hi",
        "Tamil": "ta",
        "Telugu": "te"
    }

    try:
        tts = gTTS(text=text, lang=lang_codes[lang])
        tts.save("voice.mp3")
        os.system("start voice.mp3")

    except Exception as e:
        print("Speech error:", e)


# =========================
# 📝 HISTORY
# =========================
def save_history(data):
    file_path = "history.json"

    # create file if not exists
    if not os.path.exists(file_path):
        with open(file_path, "w") as f:
            json.dump([], f)

    # read old data
    with open(file_path, "r") as f:
        history = json.load(f)

    # add new data
    history.append(data)

    # save back
    with open(file_path, "w") as f:
        json.dump(history, f, indent=4)

translations = {
    "English": {
        "city": "Enter City",
        "upload": "Upload Leaf Image",
        "predict": "Predict",
        "confidence": "Confidence",
        "weather": "Weather",
        "crop": "Recommended Crop",
        "treatment": "Treatment",
        "info": "Disease Info",
        "speak": "Speak Result",
        "soil_crop": "Soil Based Crop",
        "severity": "Severity Level",
        "fertilizer": "Recommended Fertilizer"
    },

    "Kannada": {
        "city": "ನಗರವನ್ನು ನಮೂದಿಸಿ",
        "upload": "ಎಲೆ ಚಿತ್ರವನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ",
        "predict": "ಭವಿಷ್ಯ ನಿಗದಿ",
        "confidence": "ನಂಬಿಕೆ",
        "weather": "ಹವಾಮಾನ",
        "crop": "ಶಿಫಾರಸು ಮಾಡಿದ ಬೆಳೆ",
        "treatment": "ಚಿಕಿತ್ಸೆ",
        "info": "ರೋಗದ ಮಾಹಿತಿ",
        "speak": "ಧ್ವನಿ ಫಲಿತಾಂಶ",
        "soil_crop": "ಮಣ್ಣಿನ ಆಧಾರದ ಬೆಳೆ",
        "severity": "ತೀವ್ರತೆ ಮಟ್ಟ", 
        "fertilizer": "ಶಿಫಾರಸು ಮಾಡಿದ ರಸಗೊಬ್ಬರ"
    },

    "Hindi": {
        "city": "शहर दर्ज करें",
        "upload": "पत्ती की छवि अपलोड करें",
        "predict": "भविष्यवाणी",
        "confidence": "विश्वास",
        "weather": "मौसम",
        "crop": "अनुशंसित फसल",
        "treatment": "उपचार",
        "info": "रोग की जानकारी",
        "speak": "आवाज में सुनें",
        "soil_crop": "मिट्टी आधारित फसल",
        "severity": "गंभीरता स्तर",
        "fertilizer": "अनुशंसित उर्वरक"
    },

    "Tamil": {
        "city": "நகரத்தை உள்ளிடவும்",
        "upload": "இலை படத்தை பதிவேற்றவும்",
        "predict": "கணிக்கவும்",
        "confidence": "நம்பிக்கை",
        "weather": "வானிலை",
        "crop": "பரிந்துரைக்கப்பட்ட பயிர்",
        "treatment": "சிகிச்சை",
        "info": "நோய் தகவல்",
        "speak": "குரல் வெளியீடு",
        "soil_crop": "மண் அடிப்படையிலான பயிர்",
        "severity": "தீவிரத்தன்மை நிலை",
        "fertilizer": "பரிந்துரைக்கப்பட்ட உரம்"
    },

    "Telugu": {
        "city": "నగరాన్ని నమోదు చేయండి",
        "upload": "ఆకు చిత్రాన్ని అప్‌లోడ్ చేయండి",
        "predict": "అంచనా వేయండి",
        "confidence": "నమ్మకం",
        "weather": "వాతావరణం",
        "crop": "సిఫారసు చేసిన పంట",
        "treatment": "చికిత్స",
        "info": "రోగ సమాచారం",
        "speak": "వాయిస్ ఫలితం",
        "soil_crop": "మట్టి ఆధారిత పంట",
        "severity": "తీవ్రత స్థాయి",
        "fertilizer": "సిఫారసు చేసిన ఎరువు"
    }
}


def recommend_by_soil(soil_type):
    soil_type = soil_type.lower()

    if soil_type == "loamy":
        return "Wheat, Sugarcane, Cotton"
    elif soil_type == "sandy":
        return "Groundnut, Watermelon, Coconut"
    elif soil_type == "clayey":
        return "Rice, Broccoli"
    elif soil_type == "black":
        return "Cotton, Soybean"
    else:
        return "Vegetables, Pulses"
    
def estimate_severity(confidence):
    if confidence > 0.85:
        return "High ⚠️"
    elif confidence > 0.60:
        return "Medium ⚠️"
    else:
        return "Low ✅"
    
def recommend_fertilizer(disease):
    fertilizers = {

        # 🌶 Pepper
        "Pepper__bell___Bacterial_spot":
            "Apply phosphorus-rich fertilizer. Use copper-based spray and compost.",
        "Pepper__bell___healthy":
            "Use balanced NPK fertilizer (10-10-10) for growth.",

        # 🥔 Potato
        "Potato___Early_blight":
            "Apply nitrogen and potassium-rich fertilizers. Add organic compost.",
        "Potato___Late_blight":
            "Use potassium-rich fertilizer and fungicide mix.",
        "Potato___healthy":
            "Use balanced NPK and organic manure.",

        # 🍅 Tomato
        "Tomato_Bacterial_spot":
            "Apply phosphorus-rich fertilizer and copper sprays.",
        "Tomato_Early_blight":
            "Use nitrogen-rich fertilizer and compost.",
        "Tomato_Late_blight":
            "Use potassium-rich fertilizer and avoid excess moisture.",
        "Tomato_Leaf_Mold":
            "Apply calcium and magnesium fertilizers.",
        "Tomato_Septoria_leaf_spot":
            "Use nitrogen and organic compost.",
        "Tomato_Spider_mites_Two_spotted_spider_mite":
            "Use neem-based fertilizer and organic nutrients.",
        "Tomato__Target_Spot":
            "Apply balanced NPK fertilizer and fungicides.",
        "Tomato__Tomato_YellowLeaf__Curl_Virus":
            "Use micronutrient fertilizers and control insects.",
        "Tomato__Tomato_mosaic_virus":
            "Use organic compost and avoid chemical stress.",
        "Tomato_healthy":
            "Use balanced fertilizer and proper irrigation."
    }

    return fertilizers.get(
        disease,
        "Use general NPK fertilizer with organic compost."
    )