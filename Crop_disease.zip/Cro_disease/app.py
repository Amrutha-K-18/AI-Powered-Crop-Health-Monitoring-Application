import streamlit as st

st.set_page_config(page_title="🌿 Smart Agri AI", layout="wide")

# 🌈 UI
st.markdown("""
<style>
.stApp {
    background: linear-gradient(to right, #56ab2f, #a8e063);
}
.block-container {
    background: rgba(255,255,255,0.95);
    padding: 2rem;
    border-radius: 15px;
}
</style>
""", unsafe_allow_html=True)

# 🔐 SESSION
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

# 🧾 USERS STORAGE
import json
try:
    with open("users.json") as f:
        users = json.load(f)
except:
    users = {}

# 🔐 LOGIN / SIGNUP PAGE
if not st.session_state.logged_in:
    st.title("🌿 Smart AI Crop Health Monitoring Application")
    st.markdown("Please login or signup to continue")

    tab1, tab2 = st.tabs(["🔐 Login", "📝 Signup"])

    # LOGIN
    with tab1:
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        if st.button("Login"):
            if username in users and users[username] == password:
                st.success("Login successful ✅")
                st.session_state.logged_in = True
                st.experimental_rerun()
            else:
                st.error("Invalid credentials ❌")

    # SIGNUP
    with tab2:
        new_user = st.text_input("Create Username")
        new_pass = st.text_input("Create Password", type="password")

        if st.button("Signup"):
            users[new_user] = new_pass
            with open("users.json", "w") as f:
                json.dump(users, f)
            st.success("Signup successful 🎉")

# ✅ AFTER LOGIN
else:
    st.title("🌱 Smart Agriculture AI System")

    st.success("Welcome! Use sidebar 👈")

    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.experimental_rerun()
        