import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras import layers, models
import json

# 📁 Dataset path
DATASET_PATH = "dataset/PlantVillage"

# 🔄 Data preprocessing
train_datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.2
)

train_data = train_datagen.flow_from_directory(
    DATASET_PATH,
    target_size=(224, 224),
    batch_size=32,
    subset="training"
)

val_data = train_datagen.flow_from_directory(
    DATASET_PATH,
    target_size=(224, 224),
    batch_size=32,
    subset="validation"
)

# 🏷 Save labels
labels = train_data.class_indices

with open("labels.json", "w") as f:
    json.dump(labels, f)

print("✅ Labels saved")

# 🧠 Model (Transfer Learning)
base_model = MobileNetV2(
    weights="imagenet",
    include_top=False,
    input_shape=(224, 224, 3)
)

base_model.trainable = False

model = models.Sequential([
    base_model,
    layers.GlobalAveragePooling2D(),
    layers.Dense(128, activation='relu'),
    layers.Dense(len(labels), activation='softmax')
])

# ⚙ Compile
model.compile(
    optimizer="adam",
    loss="categorical_crossentropy",
    metrics=["accuracy"]
)

# 🚀 Train
history = model.fit(
    train_data,
    validation_data=val_data,
    epochs=10
)

# 💾 Save model
model.save("plant_disease_model.h5")

print("🎉 Model saved successfully")